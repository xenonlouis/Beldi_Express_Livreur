import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
//  final String uid = FirebaseServices.uid;

  Future<String?> getFournisseurName(String fournisseurId) async {
    try {
      // Get the document snapshot for the provided fournisseurId
      DocumentSnapshot fournisseurSnapshot =
          await _firestore.collection('Fournisseurs').doc(fournisseurId).get();

      // Check if the document exists
      if (fournisseurSnapshot.exists) {
        // Get the name field from the snapshot data
        return fournisseurSnapshot.get('name');
      } else {
        // If the document does not exist, return null or handle accordingly
        return null;
      }
    } catch (e) {
      // Handle any errors that occur during the process
      print('Error getting fournisseur name: $e');
      return null;
    }
  }

  Stream<QuerySnapshot> getCommandsStream() {
    return _firestore
        .collection('Commandes')
        .where('clientId', isEqualTo: 'userId')
        .snapshots();
  }
}
